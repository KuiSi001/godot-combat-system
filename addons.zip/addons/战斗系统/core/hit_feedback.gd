class_name 受击反馈设置 extends Resource

@export_group("闪白")
@export var 启用闪白: bool = true
@export var 闪白颜色: Color = Color(1.0, 0.5, 0.5, 1.0)
@export var 闪白时长: float = 0.08

@export_group("顿帧")
@export var 启用顿帧: bool = true
## 顿帧时的时间缩放倍数（0.05 表示几乎停滞）
@export var 顿帧时间缩放: float = 0.05
## 顿帧真实持续时间（不受 time_scale 影响）
@export var 顿帧时长: float = 0.04

@export_group("击退")
@export var 启用击退: bool = true
## 击退力度的全局乘数，1.0 = 使用招式里的数值
@export var 击退系数: float = 1.0
## 击退初速度的衰减（数值越大停得越快）
@export var 击退阻力: float = 0.85

@export_group("飘字")
@export var 启用飘字: bool = true
@export var 普通字颜色: Color = Color.WHITE
@export var 暴击字颜色: Color = Color(1.0, 0.8, 0.2)
@export var 飘字大小: int = 16
@export var 飘字向上速度: float = 80.0
@export var 飘字消散时长: float = 0.8
