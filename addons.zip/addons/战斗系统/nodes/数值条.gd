@tool
class_name 数值条 extends Node2D

## 世界空间数值条（血条/盾条/蓝条）
##
## 挂在怪物头顶，自动寻找同级的 [属性组件] 并绑定。
## 支持纯色绘制和纹理绘制，自带平滑缓动与自定义粒子特效。

## 选择要显示的数值类型
enum 显示类型 {
	生命,
	护盾,
	法力,
}

## 填充纹理的缩放方式
enum 纹理填充模式 {
	拉伸,  ## 随比例缩放整张图
	裁剪,  ## 从左侧截取部分图（适合带图案、花纹的异形血条）
}

## 掉血时的动画模式
enum 动画模式 {
	瞬间,    ## 直接扣减
	平滑,    ## 当前那条平滑掉下去
	粒子,    ## 平滑掉落，并在掉血区域喷发粒子
}

## 粒子的形状
enum 粒子形状类型 {
	圆形,
	矩形,
	纹理,
}

@export var 目标数值: 显示类型 = 显示类型.生命:
	set(v):
		目标数值 = v
		queue_redraw()

@export_group("外观尺寸")
@export var 跟随纹理尺寸: bool = false:
	set(v):
		跟随纹理尺寸 = v
		notify_property_list_changed()
		_更新尺寸()
		queue_redraw()

@export var 宽度: float = 60.0:
	set(v):
		宽度 = v
		queue_redraw()
@export var 高度: float = 8.0:
	set(v):
		高度 = v
		queue_redraw()

@export_group("缓动动画")
## 掉血动画模式
@export var 动画特效: 动画模式 = 动画模式.平滑:
	set(v):
		动画特效 = v
		notify_property_list_changed()
## 平滑速度，0 表示瞬间变化。数值越大滑得越快
@export var 缓动速度: float = 5.0

@export_group("粒子特效")
## 粒子主色调（如果是带颜色的纹理，这个颜色会作为乘法叠加）
@export var 粒子颜色: Color = Color(0.8, 0.2, 0.2):
	set(v):
		粒子颜色 = v
		queue_redraw()
## 粒子形状
@export var 粒子形状: 粒子形状类型 = 粒子形状类型.圆形:
	set(v):
		粒子形状 = v
		notify_property_list_changed()
## 当形状选为「纹理」时生效
@export var 粒子纹理: Texture2D:
	set(v):
		粒子纹理 = v
		queue_redraw()
## 一次掉血最多喷发多少粒子
@export var 粒子最大数量: int = 20

@export_subgroup("粒子物理")
## 重力（向下为正）
@export var 粒子重力: float = 300.0
## 阻力（空气阻力，0.98 表示每秒衰减 2%）
@export var 粒子阻力: float = 0.98
## X轴初始速度范围
@export var 粒子初速度X_最小: float = -50.0
@export var 粒子初速度X_最大: float = 50.0
## Y轴初始速度范围（通常为负数表示向上喷发）
@export var 粒子初速度Y_最小: float = -100.0
@export var 粒子初速度Y_最大: float = -30.0

@export_subgroup("粒子随机范围")
## 粒子大小范围（如果是纹理，则作为纹理缩放后的直径）
@export var 粒子大小_最小: float = 1.5
@export var 粒子大小_最大: float = 3.5
## 粒子存活时间范围（秒）
@export var 粒子存活时间_最小: float = 0.3
@export var 粒子存活时间_最大: float = 0.6

@export_group("编辑器预览")
## 仅在编辑器非运行状态下生效，用于拖动查看血量变化效果
@export_range(0.0, 1.0, 0.01) var 编辑器预览进度: float = 1.0:
	set(v):
		编辑器预览进度 = v
		queue_redraw()

@export_group("纹理设置")
@export var 使用纹理: bool = false:
	set(v):
		使用纹理 = v
		notify_property_list_changed()
		_更新尺寸()
		queue_redraw()

@export var 背景纹理: Texture2D:
	set(v):
		背景纹理 = v
		_更新尺寸()
		queue_redraw()
@export var 背景纹理颜色: Color = Color(1, 1, 1, 1):
	set(v):
		背景纹理颜色 = v
		queue_redraw()

@export var 填充纹理: Texture2D:
	set(v):
		填充纹理 = v
		_更新尺寸()
		queue_redraw()
@export var 填充纹理颜色: Color = Color(1, 1, 1, 1):
	set(v):
		填充纹理颜色 = v
		queue_redraw()

@export var 边框纹理: Texture2D:
	set(v):
		边框纹理 = v
		_更新尺寸()
		queue_redraw()
@export var 边框纹理颜色: Color = Color(1, 1, 1, 1):
	set(v):
		边框纹理颜色 = v
		queue_redraw()

@export var 填充方式: 纹理填充模式 = 纹理填充模式.裁剪:
	set(v):
		填充方式 = v
		queue_redraw()

@export_group("纯色绘制")
@export var 背景色: Color = Color(0.1, 0.1, 0.1, 0.8):
	set(v):
		背景色 = v
		queue_redraw()
@export var 边框色: Color = Color(0.0, 0.0, 0.0, 1.0):
	set(v):
		边框色 = v
		queue_redraw()
@export var 生命颜色: Color = Color(0.8, 0.2, 0.2):
	set(v):
		生命颜色 = v
		queue_redraw()
@export var 护盾颜色: Color = Color(0.3, 0.6, 0.9):
	set(v):
		护盾颜色 = v
		queue_redraw()
@export var 法力颜色: Color = Color(0.3, 0.5, 1.0):
	set(v):
		法力颜色 = v
		queue_redraw()

var _属性组件: 属性组件
var _当前值: float = 0.0
var _最大值: float = 1.0
var _主显示值: float = 0.0

# 粒子数据结构：[ {位置, 速度, 生命, 最大生命, 大小} ]
var _粒子列表: Array[Dictionary] = []


func _validate_property(property: Dictionary) -> void:
	if 使用纹理 and 跟随纹理尺寸:
		if property.name == "宽度" or property.name == "高度":
			property.usage = PROPERTY_USAGE_NO_EDITOR
			
	if 动画特效 != 动画模式.粒子:
		var 隐藏列表 := [
			"粒子颜色", "粒子形状", "粒子纹理", "粒子最大数量",
			"粒子重力", "粒子阻力",
			"粒子初速度X_最小", "粒子初速度X_最大", "粒子初速度Y_最小", "粒子初速度Y_最大",
			"粒子大小_最小", "粒子大小_最大", 
			"粒子存活时间_最小", "粒子存活时间_最大"
		]
		if property.name in 隐藏列表:
			property.usage = PROPERTY_USAGE_NO_EDITOR
	elif 粒子形状 != 粒子形状类型.纹理:
		if property.name == "粒子纹理":
			property.usage = PROPERTY_USAGE_NO_EDITOR


func _更新尺寸() -> void:
	if not 使用纹理 or not 跟随纹理尺寸: return
	var 目标纹理: Texture2D = null
	if 填充纹理: 目标纹理 = 填充纹理
	elif 背景纹理: 目标纹理 = 背景纹理
	elif 边框纹理: 目标纹理 = 边框纹理
	
	if 目标纹理:
		宽度 = 目标纹理.get_width()
		高度 = 目标纹理.get_height()


func _ready() -> void:
	if Engine.is_editor_hint():
		_更新尺寸()
		return

	for 兄弟 in get_parent().get_children():
		if 兄弟 is 属性组件:
			_属性组件 = 兄弟
			break

	if _属性组件 == null:
		push_error("[数值条] 找不到同级『属性组件』：%s" % get_path())
		return

	_属性组件.生命值变化.connect(_当数值变化)
	_属性组件.护盾值变化.connect(_当数值变化)
	_属性组件.法力值变化.connect(_当数值变化)
	_属性组件.属性变化.connect(_当属性变化)

	_立即刷新(true)
	set_process(true)


func _当数值变化(_当前: float, _最大: float) -> void:
	_立即刷新(false)

func _当属性变化(_名: String) -> void:
	_立即刷新(false)


func _立即刷新(是初始化: bool) -> void:
	if _属性组件 == null: return
	var 快照 := _属性组件.获取快照()
	
	match 目标数值:
		显示类型.生命: _当前值 = 快照.当前生命值; _最大值 = 快照.最大生命值
		显示类型.护盾: _当前值 = 快照.当前护盾值; _最大值 = 快照.最大护盾值
		显示类型.法力: _当前值 = 快照.当前法力值; _最大值 = 快照.最大法力值

	if _最大值 <= 0.0:
		visible = false
		return
	else:
		visible = true

	if 是初始化:
		_主显示值 = _当前值
	else:
		# 发生掉血
		if _当前值 < _主显示值:
			if 动画特效 == 动画模式.瞬间:
				_主显示值 = _当前值
			elif 动画特效 == 动画模式.粒子:
				_生成粒子(_主显示值, _当前值)
		# 发生回血，主条直接跟上，防止回血时产生奇怪的特效
		elif _当前值 > _主显示值:
			if 动画特效 == 动画模式.瞬间:
				_主显示值 = _当前值

	queue_redraw()


func _process(增量: float) -> void:
	if Engine.is_editor_hint(): return

	if get_parent() is Node2D:
		var 父缩放 := (get_parent() as Node2D).global_scale.x
		scale.x = sign(父缩放) if 父缩放 != 0 else 1.0

	var 需要重绘 := false

	# 主条缓动
	if not is_equal_approx(_主显示值, _当前值):
		if 动画特效 == 动画模式.瞬间:
			_主显示值 = _当前值
		else:
			_主显示值 = lerpf(_主显示值, _当前值, 增量 * 缓动速度)
			if absf(_主显示值 - _当前值) < 0.01:
				_主显示值 = _当前值
		需要重绘 = true

	# 粒子物理更新
	if not _粒子列表.is_empty():
		需要重绘 = true
		for i in range(_粒子列表.size() - 1, -1, -1):
			var p: Dictionary = _粒子列表[i]
			var 生命: float = p["生命"] - 增量
			p["生命"] = 生命
			
			if 生命 <= 0.0:
				_粒子列表.remove_at(i)
			else:
				var pos: Vector2 = p["位置"]
				var vel: Vector2 = p["速度"]
				
				# 应用位移
				pos += vel * 增量
				
				# 应用重力与阻力
				vel.y += 粒子重力 * 增量
				vel.x *= 粒子阻力
				vel.y *= 粒子阻力
				
				p["位置"] = pos
				p["速度"] = vel

	if 需要重绘:
		queue_redraw()


func _生成粒子(旧值: float, 新值: float) -> void:
	var 差值 := 旧值 - 新值
	if 差值 <= 0.0: return
	
	var 数量 := clampi(int(差值), 1, 粒子最大数量)
	var 半宽 := 宽度 * 0.5
	var 半高 := 高度 * 0.5
	var 起始比例 := 新值 / _最大值
	var 结束比例 := 旧值 / _最大值

	for i in 数量:
		var 比例 := randf_range(起始比例, 结束比例)
		var 起始位置 := Vector2(-半宽 + 宽度 * 比例, randf_range(-半高, 半高))
		var 速度 := Vector2(
			randf_range(粒子初速度X_最小, 粒子初速度X_最大), 
			randf_range(粒子初速度Y_最小, 粒子初速度Y_最大)
		)
		var 大小 := randf_range(粒子大小_最小, 粒子大小_最大)
		var 存活时间 := randf_range(粒子存活时间_最小, 粒子存活时间_最大)
		
		_粒子列表.append({
			"位置": 起始位置, 
			"速度": 速度, 
			"生命": 存活时间, 
			"最大生命": 存活时间, 
			"大小": 大小
		})


func _绘制条段(目标矩形: Rect2, 显示比例: float) -> void:
	if 使用纹理:
		if 填充纹理 and 显示比例 > 0.0:
			if 填充方式 == 纹理填充模式.裁剪:
				var 纹理尺寸 := 填充纹理.get_size()
				if 纹理尺寸.x > 0.0:
					var 切出区域 := Rect2(0, 0, 纹理尺寸.x * 显示比例, 纹理尺寸.y)
					draw_texture_rect_region(填充纹理, 目标矩形, 切出区域, 填充纹理颜色)
			else:
				draw_texture_rect(填充纹理, 目标矩形, false, 填充纹理颜色)
	else:
		var 颜色: Color
		match 目标数值:
			显示类型.生命: 颜色 = 生命颜色
			显示类型.护盾: 颜色 = 护盾颜色
			显示类型.法力: 颜色 = 法力颜色
		draw_rect(目标矩形, 颜色, true)


func _draw() -> void:
	var 半宽 := 宽度 * 0.5
	var 半高 := 高度 * 0.5
	var 矩形 := Rect2(-半宽, -半高, 宽度, 高度)

	var 主比例: float = 1.0
	if Engine.is_editor_hint():
		主比例 = 编辑器预览进度
	else:
		主比例 = clampf(_主显示值 / _最大值, 0.0, 1.0)
		
	var 主填充矩形 := Rect2(-半宽, -半高, 宽度 * 主比例, 高度)

	if 使用纹理:
		if 背景纹理:
			draw_texture_rect(背景纹理, 矩形, false, 背景纹理颜色)

		# 画主条
		if 主比例 > 0.0:
			_绘制条段(主填充矩形, 主比例)

		if 边框纹理:
			draw_texture_rect(边框纹理, 矩形, false, 边框纹理颜色)
	else:
		draw_rect(矩形, 背景色, true)

		if 主比例 > 0.0:
			_绘制条段(主填充矩形, 主比例)

		draw_rect(矩形, 边框色, false, 1.0)

	# 绘制粒子
	if not Engine.is_editor_hint():
		for p in _粒子列表:
			var 生命: float = p["生命"]
			var 最大生命: float = p["最大生命"]
			var 透明度: float = 生命 / 最大生命
			var c := 粒子颜色
			c.a *= 透明度
			
			var pos: Vector2 = p["位置"]
			var 大小: float = p["大小"]
			
			match 粒子形状:
				粒子形状类型.圆形:
					draw_circle(pos, 大小 * 透明度, c)
				粒子形状类型.矩形:
					var rect := Rect2(pos - Vector2(大小, 大小) * 透明度, Vector2(大小 * 2.0, 大小 * 2.0) * 透明度)
					draw_rect(rect, c, true)
				粒子形状类型.纹理:
					if 粒子纹理:
						var 尺寸 := 大小 * 透明度
						var 目标矩形 := Rect2(pos - Vector2(尺寸, 尺寸), Vector2(尺寸 * 2.0, 尺寸 * 2.0))
						draw_texture_rect(粒子纹理, 目标矩形, false, c)
