extends Window

## 战斗系统调试面板（嵌入式）
## 按 F2 开启/关闭。自动扫描场景中的属性组件，按离摄像机距离排序。

var _列表: ItemList
var _属性容器: VBoxContainer
var _当前选中节点: Node2D
var _刷新计时: float = 0.0
## 可选：拖入玩家节点，列表将以此节点为中心计算距离
## 留空时，会尝试获取当前激活的 Camera2D
@export var 参照目标: Node2D


func _ready() -> void:
	# 嵌入式窗口基础设置
	title = "战斗数值调试面板 (按 F2 隐藏/显示)"
	size = Vector2i(1280, 720)  # 适配 1080p 的高度
	always_on_top = true
	visible = false 
	
	# 默认居中
	_居中窗口()
	
	# 监听主窗口按键（防止子窗口隐藏后收不到 F2）
	get_tree().root.window_input.connect(_当主窗口收到输入)
	
	_构建界面()
	
	# 拦截窗口的关闭请求
	close_requested.connect(_当点击关闭按钮)


func _当主窗口收到输入(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and not event.echo:
		if event.keycode == KEY_F2:
			visible = not visible
			if visible:
				_居中窗口()


## 嵌入式视口居中
func _居中窗口() -> void:
	# 获取游戏主视口的大小，计算中心点
	var 视口尺寸 = get_tree().root.size
	position = Vector2i(
		(视口尺寸.x - size.x) / 2,
		(视口尺寸.y - size.y) / 2
	)


func _process(delta: float) -> void:
	if not visible:
		return
		
	_刷新计时 += delta
	if _刷新计时 > 0.5:
		_刷新计时 = 0.0
		_刷新列表()


# ─────────────────────────────────────────
#  UI 构建
# ─────────────────────────────────────────
func _构建界面() -> void:
	var 主容器 := MarginContainer.new()
	主容器.set_anchors_preset(Control.PRESET_FULL_RECT)
	主容器.add_theme_constant_override("margin_left", 10)
	主容器.add_theme_constant_override("margin_right", 10)
	主容器.add_theme_constant_override("margin_top", 10)
	主容器.add_theme_constant_override("margin_bottom", 10)
	add_child(主容器)

	var 主HBox := HBoxContainer.new()
	主容器.add_child(主HBox)

	# 左侧：目标列表
	var 左侧VBox := VBoxContainer.new()
	左侧VBox.custom_minimum_size = Vector2(180, 0) 
	主HBox.add_child(左侧VBox)

	var 列表标题 := Label.new()
	列表标题.text = "场景目标 (由近到远)"
	左侧VBox.add_child(列表标题)

	_列表 = ItemList.new()
	_列表.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_列表.item_selected.connect(_当选中目标)
	左侧VBox.add_child(_列表)

	# 中间画一条竖线分隔
	var 分割线 := VSeparator.new()
	主HBox.add_child(分割线)

	# 右侧：属性调整
	var 右侧VBox := VBoxContainer.new()
	右侧VBox.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	主HBox.add_child(右侧VBox)

	var 属性标题 := Label.new()
	属性标题.text = "属性调试 (滑块或直接输入)"
	右侧VBox.add_child(属性标题)

	var 滚动 := ScrollContainer.new()
	滚动.size_flags_vertical = Control.SIZE_EXPAND_FILL
	滚动.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	右侧VBox.add_child(滚动)

	_属性容器 = VBoxContainer.new()
	_属性容器.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	滚动.add_child(_属性容器)

# ─────────────────────────────────────────
#  核心逻辑
# ─────────────────────────────────────────
func _刷新列表() -> void:
	var 中心点 := Vector2.ZERO
	
	# 1. 优先级：手动设置的参照目标
	if 参照目标 != null and is_instance_valid(参照目标):
		中心点 = 参照目标.global_position
	else:
		# 2. 尝试获取当前激活的摄像机中心
		var 摄像机 := get_viewport().get_camera_2d()
		if 摄像机:
			中心点 = 摄像机.get_screen_center_position()
		else:
			# 3. 暴力找场景里第一个摄像机
			摄像机 = get_tree().root.find_child("*Camera2D*", true, false)
			if 摄像机:
				中心点 = (摄像机 as Camera2D).get_screen_center_position()
			else:
				# 4. 再找不到，就暴力找场景里名字带 Player 或 玩家 的节点
				var 玩家 = get_tree().root.find_child("*Player*", true, false)
				if 玩家 == null:
					玩家 = get_tree().root.find_child("*玩家*", true, false)
				if 玩家 is Node2D:
					中心点 = (玩家 as Node2D).global_position

	var 目标列表: Array = []

	for 组件 in get_tree().root.find_children("*", "属性组件", true, false):
		if 组件.get_parent() is Node2D:
			var 父节点 := 组件.get_parent() as Node2D
			var 距离 := 父节点.global_position.distance_to(中心点)
			目标列表.append({ "节点": 父节点, "组件": 组件, "距离": 距离 })

	目标列表.sort_custom(func(a, b): return a.距离 < b.距离)

	_列表.clear()
	for 目标 in 目标列表:
		var 父名: String = str(目标.节点.name)
		if 目标.节点 == _当前选中节点:
			父名 = "👉 " + 父名
		var 索引 := _列表.add_item("%s (%.0fm)" % [父名, 目标.距离])
		_列表.set_item_metadata(索引, 目标.节点)

	if _当前选中节点 != null and not is_instance_valid(_当前选中节点):
		_当前选中节点 = null
		_清空属性UI()


func _当选中目标(索引: int) -> void:
	var 节点 = _列表.get_item_metadata(索引)
	if 节点 == null or not is_instance_valid(节点): return
	
	_当前选中节点 = 节点
	_清空属性UI()

	var 组件 = _获取节点上的属性组件(_当前选中节点)
	if 组件 == null: return
	var 模板: 属性模板 = 组件.模板
	if 模板 == null: return

	for 属性名 in _获取所有属性名(模板):
		var 行 := HBoxContainer.new()
		_属性容器.add_child(行)

		var 标签 := Label.new()
		标签.text = 属性名
		标签.custom_minimum_size = Vector2(160, 0)
		行.add_child(标签)

		var 滑动条 := HSlider.new()
		var 当前值: float = float(模板.get(属性名))
		滑动条.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		
		var 是百分比 = 属性名.contains("率") or 属性名.contains("减伤") or 属性名.contains("百分比") or 属性名.contains("效率")
		var 是整数 = 属性名.contains("次数")
		
		if 是百分比:
			滑动条.min_value = -1.0
			滑动条.max_value = 2.0
			滑动条.step = 0.01
		elif 是整数:
			滑动条.min_value = 0.0
			滑动条.max_value = 10.0
			滑动条.step = 1.0
		else:
			滑动条.min_value = 0.0
			滑动条.max_value = 2000.0
			滑动条.step = 1.0
			
		滑动条.value = 当前值
		行.add_child(滑动条)

		var 数字框 := SpinBox.new()
		数字框.custom_minimum_size = Vector2(90, 0)
		数字框.max_value = 99999.0
		数字框.min_value = -9999.0
		数字框.step = 0.01 if 是百分比 else 1.0
		数字框.value = 当前值
		行.add_child(数字框)

		var 正在更新 := [false] 

		滑动条.value_changed.connect(func(新值):
			if 正在更新[0]: return
			正在更新[0] = true
			数字框.value = 新值
			模板.set(属性名, 新值)
			if 属性名 == "最大生命值" or 属性名 == "最大护盾值":
				组件.重置状态()
			正在更新[0] = false
		)

		数字框.value_changed.connect(func(新值):
			if 正在更新[0]: return
			正在更新[0] = true
			滑动条.value = 新值
			模板.set(属性名, 新值)
			if 属性名 == "最大生命值" or 属性名 == "最大护盾值":
				组件.重置状态()
			正在更新[0] = false
		)

func _清空属性UI() -> void:
	for 子 in _属性容器.get_children():
		子.queue_free()

func _获取节点上的属性组件(节点: Node) -> 属性组件:
	for 子 in 节点.get_children():
		if 子 is 属性组件:
			return 子
	return null

func _获取所有属性名(对象: Object) -> Array[String]:
	var 名字列表: Array[String] = []
	for 属性 in 对象.get_property_list():
		if 属性.usage & PROPERTY_USAGE_EDITOR:
			if 属性.type == TYPE_FLOAT or 属性.type == TYPE_INT:
				名字列表.append(属性.name)
	return 名字列表


func _当点击关闭按钮() -> void:
	# 当点击右上角 X 时，仅仅隐藏，不销毁节点
	visible = false
