@tool
extends EditorPlugin

const 属性组件脚本 = preload("res://addons/战斗系统/nodes/stats_component.gd")
const 攻击盒脚本   = preload("res://addons/战斗系统/nodes/attack_hitbox.gd")
const 受击盒脚本   = preload("res://addons/战斗系统/nodes/hurtbox.gd")
const 数值条脚本   = preload("res://addons/战斗系统/nodes/数值条.gd") # ← 新增

func _enter_tree() -> void:
	add_custom_type("属性组件", "Node",   属性组件脚本, null)
	add_custom_type("攻击盒",   "Area2D", 攻击盒脚本,   null)
	add_custom_type("受击盒",   "Area2D", 受击盒脚本,   null)
	add_custom_type("数值条",   "Node2D", 数值条脚本,   null) # ← 新增
	print("[战斗系统] 插件已启用")

func _exit_tree() -> void:
	remove_custom_type("属性组件")
	remove_custom_type("攻击盒")
	remove_custom_type("受击盒")
	remove_custom_type("数值条") # ← 新增
	print("[战斗系统] 插件已禁用")
