class_name 属性模板 extends Resource

## 属性基础值模板
##
## 角色的所有战斗数值基础值。攻击方 / 防守方 / UI 都从这里读初始数值，
## 运行时通过 [属性组件] 叠加修改器。
##
## [b]字段很多，用不到的直接保持默认值即可[/b]，不会影响运行。

# ── 生命 ──
@export_group("生命")
@export var 最大生命值: float = 100.0
@export var 生命回复: float = 0.0
@export var 生命偷取: float = 0.0
@export var 生命偷取效率: float = 1.0
@export var 最大生命百分比: float = 0.0

# ── 护盾 ──
@export_group("护盾")
@export var 最大护盾值: float = 0.0
@export var 护盾回复: float = 0.0
@export var 护盾回复延迟: float = 0.0
@export var 护盾强度: float = 1.0

# ── 法力 ──
@export_group("法力")
@export var 最大法力值: float = 0.0
@export var 法力回复: float = 0.0

# ── 进攻 - 通用 ──
@export_group("进攻-通用")
@export var 伤害加成: float = 0.0
@export var 命中率: float = 1.0
@export var 暴击率: float = 0.0
@export var 暴击倍率: float = 1.5
@export var 暴击伤害加成: float = 0.0
@export var 攻击速度: float = 1.0
@export var 攻击范围: float = 1.0

# ── 进攻 - 物理 ──
@export_group("进攻-物理")
@export var 物理攻击: float = 10.0
@export var 物理穿透: float = 0.0
@export var 物理穿透率: float = 0.0
@export var 物理伤害加成: float = 0.0

# ── 进攻 - 法术 ──
@export_group("进攻-法术")
@export var 法术攻击: float = 10.0
@export var 法术穿透: float = 0.0
@export var 法术穿透率: float = 0.0
@export var 法术伤害加成: float = 0.0
@export var 冷却缩减: float = 0.0

# ── 进攻 - 特殊 ──
@export_group("进攻-特殊")
@export var 对盾伤害加成: float = 0.0
@export var 低血增伤: float = 0.0
@export var 低血阈值: float = 0.3
@export var 满血增伤: float = 0.0

# ── 防御 - 基础 ──
@export_group("防御-基础")
@export var 物理防御: float = 0.0
@export var 法术防御: float = 0.0
@export var 最终减伤: float = 0.0

# ── 防御 - 进阶 ──
@export_group("防御-进阶")
@export var 闪避率: float = 0.0
@export var 格挡率: float = 0.0
@export var 格挡减伤: float = 0.5
@export var 暴击抗性: float = 0.0
@export var 韧性: float = 0.0

# ── 移动 ──
@export_group("移动")
@export var 移动速度: float = 200.0
@export var 加速度: float = 2000.0
@export var 减速度: float = 3000.0
@export var 跳跃力: float = 400.0
@export var 跳跃次数: int = 1
@export var 冲刺次数: int = 1

# ── 受击 ──
@export_group("受击")
@export var 受击无敌时间: float = 0.0
@export var 霸体阈值: float = 0.0
@export var 击退抗性: float = 0.0
@export var 受击硬直抗性: float = 0.0
@export var 反伤比例: float = 0.0
