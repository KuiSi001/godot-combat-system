class_name 伤害数据 extends Resource

## 一次攻击的招式描述 + 结算结果
##
## [b]配置字段[/b]：策划在检查器里填
## [b]运行时字段[/b]：伤害计算器写入，不要手动改

enum 伤害类型 { 物理, 法术, 真实 }

@export_group("招式描述")
@export var 伤害类别: 伤害类型 = 伤害类型.物理
@export var 攻击属性名: String = "物理攻击"
@export var 招式倍率: float = 1.0
@export var 固定加值: float = 0.0

@export_group("附加")
@export var 击退力度: float = 0.0
@export var 击退方向: Vector2 = Vector2.ZERO
@export var 无视护盾: bool = false
@export var 可暴击: bool = true

@export_group("运行结果（只读）")
## 最终伤害（含所有加成 / 减免）
@export var 最终伤害: float = 0.0
## 是否暴击
@export var 是否暴击: bool = false
## 是否命中（闪避时 false）
@export var 是否命中: bool = true
## 是否格挡
@export var 是否格挡: bool = false
