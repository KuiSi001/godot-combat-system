@tool
class_name UI属性条 extends Control

## UI 专用数值条。融合了 Node2D 版的所有特效（纹理染色/裁剪/多形状粒子），
## 支持跨场景绑定，自动适配 UI 的尺寸与坐标。

enum 显示类型 { 生命, 护盾, 法力 }
enum 绑定模式 { 手动拖拽, 按分组查找, 仅代码绑定 }
enum 纹理填充模式 { 拉伸, 裁剪 }
enum 动画模式 { 瞬间, 平滑, 粒子 }
enum 粒子形状类型 { 圆形, 矩形, 纹理 }

@export_group("目标绑定")
@export var 绑定方式: 绑定模式 = 绑定模式.手动拖拽:
	set(v):
		绑定方式 = v
		if is_inside_tree(): _重新绑定()

@export var 目标属性组件: 属性组件:
	set(v):
		目标属性组件 = v
		if is_inside_tree(): _执行绑定()
		queue_redraw()

@export var 目标分组名: String = "玩家"
@export var 目标数值: 显示类型 = 显示类型.生命:
	set(v):
		目标数值 = v
		queue_redraw()

@export_group("外观尺寸")
@export var 跟随纹理尺寸: bool = false:
	set(v):
		跟随纹理尺寸 = v
		notify_property_list_changed()
		_更新尺寸()
		queue_redraw()

@export_group("纹理设置")
@export var 使用纹理: bool = false:
	set(v):
		使用纹理 = v
		notify_property_list_changed()
		_更新尺寸()
		queue_redraw()

@export var 背景纹理: Texture2D:
	set(v):
		背景纹理 = v
		_更新尺寸()
		queue_redraw()
@export var 背景纹理颜色: Color = Color(1, 1, 1, 1):
	set(v):
		背景纹理颜色 = v
		queue_redraw()

@export var 填充纹理: Texture2D:
	set(v):
		填充纹理 = v
		_更新尺寸()
		queue_redraw()
@export var 填充纹理颜色: Color = Color(1, 1, 1, 1):
	set(v):
		填充纹理颜色 = v
		queue_redraw()

@export var 边框纹理: Texture2D:
	set(v):
		边框纹理 = v
		_更新尺寸()
		queue_redraw()
@export var 边框纹理颜色: Color = Color(1, 1, 1, 1):
	set(v):
		边框纹理颜色 = v
		queue_redraw()

@export var 填充方式: 纹理填充模式 = 纹理填充模式.裁剪:
	set(v):
		填充方式 = v
		queue_redraw()

@export_group("纯色设置")
@export var 背景色: Color = Color(0.1, 0.1, 0.1, 0.8):
	set(v):
		背景色 = v
		queue_redraw()
@export var 边框色: Color = Color(0.0, 0.0, 0.0, 1.0):
	set(v):
		边框色 = v
		queue_redraw()
		
@export_subgroup("纯色分项颜色")
@export var 生命颜色: Color = Color(0.8, 0.2, 0.2):
	set(v):
		生命颜色 = v
		queue_redraw()
@export var 护盾颜色: Color = Color(0.3, 0.6, 0.9):
	set(v):
		护盾颜色 = v
		queue_redraw()
@export var 法力颜色: Color = Color(0.3, 0.5, 1.0):
	set(v):
		法力颜色 = v
		queue_redraw()

@export_group("动画特效")
@export var 动画特效: 动画模式 = 动画模式.平滑:
	set(v):
		动画特效 = v
		notify_property_list_changed()
@export var 缓动速度: float = 5.0

@export_subgroup("粒子特效")
@export var 粒子颜色: Color = Color(0.8, 0.2, 0.2):
	set(v):
		粒子颜色 = v
		queue_redraw()
@export var 粒子形状: 粒子形状类型 = 粒子形状类型.圆形:
	set(v):
		粒子形状 = v
		notify_property_list_changed()
		queue_redraw()
@export var 粒子纹理: Texture2D:
	set(v):
		粒子纹理 = v
		queue_redraw()
@export var 粒子最大数量: int = 20
@export var 粒子重力: float = 300.0
@export var 粒子阻力: float = 0.98
@export var 粒子初速度X_最小: float = -50.0
@export var 粒子初速度X_最大: float = 50.0
@export var 粒子初速度Y_最小: float = -100.0
@export var 粒子初速度Y_最大: float = -30.0
@export var 粒子大小_最小: float = 1.5
@export var 粒子大小_最大: float = 3.5
@export var 粒子存活时间_最小: float = 0.3
@export var 粒子存活时间_最大: float = 0.6

@export_group("文字显示")
@export var 显示文字: bool = true:
	set(v):
		显示文字 = v
		queue_redraw()
@export var 文字颜色: Color = Color.WHITE
@export var 文字大小: int = 14

# 运行时数据
var _当前值: float = 0.0
var _最大值: float = 1.0
var _主显示值: float = 0.0
var _粒子列表: Array[Dictionary] = []

# 智能隐藏不相关的检查器属性
func _validate_property(property: Dictionary) -> void:
	if 绑定方式 != 绑定模式.手动拖拽 and property.name == "目标属性组件":
		property.usage = PROPERTY_USAGE_NO_EDITOR
	if 绑定方式 != 绑定模式.按分组查找 and property.name == "目标分组名":
		property.usage = PROPERTY_USAGE_NO_EDITOR
		
	if not 使用纹理:
		if property.name in ["背景纹理", "背景纹理颜色", "填充纹理", "填充纹理颜色", "边框纹理", "边框纹理颜色", "填充方式"]:
			property.usage = PROPERTY_USAGE_NO_EDITOR
	else:
		if property.name in ["背景色", "边框色", "生命颜色", "护盾颜色", "法力颜色"]:
			property.usage = PROPERTY_USAGE_NO_EDITOR
			
	if 动画特效 != 动画模式.粒子:
		var 隐藏列表 := [
			"粒子颜色", "粒子形状", "粒子纹理", "粒子最大数量", "粒子重力", "粒子阻力",
			"粒子初速度X_最小", "粒子初速度X_最大", "粒子初速度Y_最小", "粒子初速度Y_最大",
			"粒子大小_最小", "粒子大小_最大", "粒子存活时间_最小", "粒子存活时间_最大"
		]
		if property.name in 隐藏列表:
			property.usage = PROPERTY_USAGE_NO_EDITOR
	elif 粒子形状 != 粒子形状类型.纹理:
		if property.name == "粒子纹理":
			property.usage = PROPERTY_USAGE_NO_EDITOR

func _更新尺寸() -> void:
	if not 使用纹理 or not 跟随纹理尺寸: return
	var 目标纹理: Texture2D = null
	if 填充纹理: 目标纹理 = 填充纹理
	elif 背景纹理: 目标纹理 = 背景纹理
	elif 边框纹理: 目标纹理 = 边框纹理
	
	if 目标纹理:
		custom_minimum_size = 目标纹理.get_size()
		size = 目标纹理.get_size()

func _ready() -> void:
	if Engine.is_editor_hint(): 
		_更新尺寸()
		return
	_重新绑定()
	set_process(true)

# ─────────────────────────────────────────
#  跨场景绑定逻辑
# ─────────────────────────────────────────
func _重新绑定() -> void:
	if Engine.is_editor_hint(): return
	
	if 绑定方式 == 绑定模式.按分组查找:
		var 目标节点 = get_tree().get_first_node_in_group(目标分组名)
		if 目标节点:
			目标属性组件 = _获取节点上的属性组件(目标节点)
			_执行绑定()
		else:
			_延迟查找()
	else:
		_执行绑定()

func _延迟查找() -> void:
	if not is_inside_tree(): return
	await get_tree().process_frame
	if not is_inside_tree(): return
	
	var 目标节点 = get_tree().get_first_node_in_group(目标分组名)
	if 目标节点:
		目标属性组件 = _获取节点上的属性组件(目标节点)
		_执行绑定()

func _执行绑定() -> void:
	if 目标属性组件 == null: return
	if 目标属性组件.生命值变化.is_connected(_当数值变化):
		目标属性组件.生命值变化.disconnect(_当数值变化)
		目标属性组件.护盾值变化.disconnect(_当数值变化)
		目标属性组件.法力值变化.disconnect(_当数值变化)
		目标属性组件.属性变化.disconnect(_当属性变化)
		
	目标属性组件.生命值变化.connect(_当数值变化)
	目标属性组件.护盾值变化.connect(_当数值变化)
	目标属性组件.法力值变化.connect(_当数值变化)
	目标属性组件.属性变化.connect(_当属性变化)
	
	_立即刷新(true)

func 绑定目标(目标节点: Node) -> void:
	绑定方式 = 绑定模式.仅代码绑定
	目标属性组件 = _获取节点上的属性组件(目标节点)
	_执行绑定()

func _获取节点上的属性组件(节点: Node) -> 属性组件:
	if 节点 is 属性组件: return 节点
	for 子 in 节点.get_children():
		if 子 is 属性组件: return 子
	return null

# ─────────────────────────────────────────
#  数据与动画逻辑
# ─────────────────────────────────────────
func _当数值变化(_当前: float, _最大: float) -> void:
	_立即刷新(false)

func _当属性变化(_名: String) -> void:
	_立即刷新(false)

func _立即刷新(是初始化: bool) -> void:
	if 目标属性组件 == null: return
	var 快照 = 目标属性组件.获取快照()
	
	match 目标数值:
		显示类型.生命:
			_当前值 = 快照.当前生命值
			_最大值 = 快照.最大生命值
		显示类型.护盾:
			_当前值 = 快照.当前护盾值
			_最大值 = 快照.最大护盾值
		显示类型.法力:
			_当前值 = 快照.当前法力值
			_最大值 = 快照.最大法力值

	if _最大值 <= 0.0:
		visible = false
		return
	else:
		visible = true

	if 是初始化:
		_主显示值 = _当前值
	else:
		# 掉血
		if _当前值 < _主显示值:
			if 动画特效 == 动画模式.瞬间:
				_主显示值 = _当前值
			elif 动画特效 == 动画模式.粒子:
				_生成粒子(_主显示值, _当前值)
		# 回血
		elif _当前值 > _主显示值:
			if 动画特效 == 动画模式.瞬间:
				_主显示值 = _当前值
	queue_redraw()

func _process(delta: float) -> void:
	if Engine.is_editor_hint(): return
	
	var 需要重绘 := false

	# 主条缓动
	if not is_equal_approx(_主显示值, _当前值):
		if 动画特效 == 动画模式.瞬间:
			_主显示值 = _当前值
		else:
			_主显示值 = lerpf(_主显示值, _当前值, delta * 缓动速度)
			if absf(_主显示值 - _当前值) < 0.1:
				_主显示值 = _当前值
		需要重绘 = true

	# 粒子物理
	if not _粒子列表.is_empty():
		需要重绘 = true
		for i in range(_粒子列表.size() - 1, -1, -1):
			var p: Dictionary = _粒子列表[i]
			var 生命: float = p["生命"] - delta
			p["生命"] = 生命
			
			if 生命 <= 0.0:
				_粒子列表.remove_at(i)
			else:
				var pos: Vector2 = p["位置"]
				var vel: Vector2 = p["速度"]
				pos += vel * delta
				vel.y += 粒子重力 * delta
				vel.x *= 粒子阻力
				vel.y *= 粒子阻力
				p["位置"] = pos
				p["速度"] = vel

	if 需要重绘:
		queue_redraw()

func _生成粒子(旧值: float, 新值: float) -> void:
	var 差值 = 旧值 - 新值
	if 差值 <= 0.0: return
	
	var 数量 = clampi(int(差值), 1, 粒子最大数量)
	var 起始比例 = 新值 / _最大值
	var 结束比例 = 旧值 / _最大值

	for i in 数量:
		var 比例 = randf_range(起始比例, 结束比例)
		# UI 坐标原点左上角，Y 轴 0 到 size.y
		var 起始位置 = Vector2(size.x * 比例, randf_range(0, size.y))
		var 速度 = Vector2(
			randf_range(粒子初速度X_最小, 粒子初速度X_最大), 
			randf_range(粒子初速度Y_最小, 粒子初速度Y_最大)
		)
		var 大小 = randf_range(粒子大小_最小, 粒子大小_最大)
		var 存活时间 = randf_range(粒子存活时间_最小, 粒子存活时间_最大)
		
		_粒子列表.append({
			"位置": 起始位置, "速度": 速度, 
			"生命": 存活时间, "最大生命": 存活时间, "大小": 大小
		})

# ─────────────────────────────────────────
#  绘制引擎
# ─────────────────────────────────────────
func _获取当前主色() -> Color:
	match 目标数值:
		显示类型.生命: return 生命颜色
		显示类型.护盾: return 护盾颜色
		显示类型.法力: return 法力颜色
	return Color.WHITE

func _绘制条段(目标矩形: Rect2, 显示比例: float) -> void:
	if 使用纹理:
		if 填充纹理 and 显示比例 > 0.0:
			if 填充方式 == 纹理填充模式.裁剪:
				var 纹理尺寸 = 填充纹理.get_size()
				if 纹理尺寸.x > 0.0:
					var 切出区域 = Rect2(0, 0, 纹理尺寸.x * 显示比例, 纹理尺寸.y)
					draw_texture_rect_region(填充纹理, 目标矩形, 切出区域, 填充纹理颜色)
			else:
				draw_texture_rect(填充纹理, 目标矩形, false, 填充纹理颜色)
	else:
		draw_rect(目标矩形, _获取当前主色(), true)

func _draw() -> void:
	var 矩形 := Rect2(0, 0, size.x, size.y)
	var 主比例: float = 1.0
	
	if not Engine.is_editor_hint():
		主比例 = clampf(_主显示值 / _最大值, 0.0, 1.0)
		
	var 主填充矩形 := Rect2(0, 0, size.x * 主比例, size.y)

	# 1. 背景
	if 使用纹理:
		if 背景纹理:
			draw_texture_rect(背景纹理, 矩形, false, 背景纹理颜色)
	else:
		draw_rect(矩形, 背景色, true)

	# 2. 主条
	if 主比例 > 0.0:
		_绘制条段(主填充矩形, 主比例)

	# 3. 边框
	if 使用纹理:
		if 边框纹理:
			draw_texture_rect(边框纹理, 矩形, false, 边框纹理颜色)
	else:
		draw_rect(矩形, 边框色, false, 2.0)

	# 4. 粒子
	if not Engine.is_editor_hint():
		for p in _粒子列表:
			var 生命: float = p["生命"]
			var 最大生命: float = p["最大生命"]
			var 透明度: float = 生命 / 最大生命
			var c = 粒子颜色
			c.a *= 透明度
			
			var pos: Vector2 = p["位置"]
			var 大小: float = p["大小"]
			
			match 粒子形状:
				粒子形状类型.圆形:
					draw_circle(pos, 大小 * 透明度, c)
				粒子形状类型.矩形:
					var rect := Rect2(pos - Vector2(大小, 大小) * 透明度, Vector2(大小 * 2.0, 大小 * 2.0) * 透明度)
					draw_rect(rect, c, true)
				粒子形状类型.纹理:
					if 粒子纹理:
						var 尺寸 := 大小 * 透明度
						var 目标矩形 := Rect2(pos - Vector2(尺寸, 尺寸), Vector2(尺寸 * 2.0, 尺寸 * 2.0))
						draw_texture_rect(粒子纹理, 目标矩形, false, c)

	# 5. 文字
	if 显示文字 and not Engine.is_editor_hint():
		var 字体 = ThemeDB.fallback_font
		var 文字 = "%d / %d" % [int(_当前值), int(_最大值)]
		var 文字尺寸 = 字体.get_string_size(文字, HORIZONTAL_ALIGNMENT_LEFT, -1, 文字大小)
		var 文字位置 = Vector2((size.x - 文字尺寸.x) / 2, (size.y / 2) + (文字尺寸.y / 3))
		draw_string(字体, 文字位置, 文字, HORIZONTAL_ALIGNMENT_LEFT, -1, 文字大小, 文字颜色)
