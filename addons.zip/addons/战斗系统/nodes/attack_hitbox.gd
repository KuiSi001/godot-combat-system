class_name 攻击盒 extends Area2D

signal 命中(受击盒节点: 受击盒, 伤害: 伤害数据)

@export var 所属阵营: 阵营.类型 = 阵营.类型.A

@export var 招式: 伤害数据 = null:
	set(值):
		招式 = 值
		if 招式 == null:
			招式 = _默认招式()

@export var 启用: bool = false:
	set(值):
		var 之前 := 启用
		启用 = 值
		if is_inside_tree():
			monitoring = 值
		queue_redraw()
		if 值 and not 之前:
			_已命中目标.clear()
			_延迟扫描.call_deferred()

@export var 显示调试徽章: bool = true
@export var 徽章位置偏移: Vector2 = Vector2(0, -50)

var _属性组件: 属性组件
var _已命中目标: Array[受击盒] = []
var _上次调试状态: bool = false


static func _默认招式() -> 伤害数据:
	var 数据 := 伤害数据.new()
	数据.伤害类别 = 伤害数据.伤害类型.物理
	数据.攻击属性名 = "物理攻击"
	数据.招式倍率 = 1.0
	return 数据


func _ready() -> void:
	if 招式 == null:
		招式 = _默认招式()
	_属性组件 = _查找同级属性组件()
	if _属性组件 == null:
		push_error("[攻击盒] 需要同级『属性组件』，节点已禁用：%s" % get_path())
		monitoring = false
		monitorable = false
		return
	monitorable = false
	启用 = false
	area_entered.connect(_当有区域进入)
	_上次调试状态 = get_tree().debug_collisions_hint
	set_process(true)


func _查找同级属性组件() -> 属性组件:
	for 兄弟 in get_parent().get_children():
		if 兄弟 is 属性组件:
			return 兄弟
	return null


func 获取属性组件() -> 属性组件:
	return _属性组件


func _process(_增量: float) -> void:
	var 当前 := get_tree().debug_collisions_hint
	if 当前 != _上次调试状态:
		_上次调试状态 = 当前
		queue_redraw()


func _延迟扫描() -> void:
	await get_tree().physics_frame
	if not 启用:
		return
	for 区域 in get_overlapping_areas():
		_当有区域进入(区域)


func 开启攻击() -> void: 启用 = true
func 关闭攻击() -> void: 启用 = false
func 重置命中表() -> void: _已命中目标.clear()
func 强制关闭() -> void: 启用 = false


func _当有区域进入(区域: Area2D) -> void:
	if not 区域 is 受击盒:
		return
	var 目标 := 区域 as 受击盒
	if 目标 in _已命中目标:
		return
	if not 阵营.可以攻击(所属阵营, 目标.所属阵营):
		return
	var 目标属性 := 目标.获取属性组件()
	if 目标属性 == null or _属性组件 == null:
		return
	var 结果 := 伤害计算器.计算(_属性组件, 目标属性, 招式)
	_已命中目标.append(目标)
	命中.emit(目标, 结果)
	目标.接收伤害(结果, self)


# ── 可视化 ──
const _轮廓色 := Color(1.0, 0.35, 0.35, 0.85)
const _轮廓填充 := Color(1.0, 0.35, 0.35, 0.10)

func _draw() -> void:
	if not 显示调试徽章:
		return
	if not get_tree().debug_collisions_hint:
		return
	for 子 in get_children():
		if not 子 is CollisionShape2D:
			continue
		var 形状: Shape2D = (子 as CollisionShape2D).shape
		if 形状 == null:
			continue
		if 形状 is CircleShape2D:
			var 圆 := 形状 as CircleShape2D
			draw_circle(子.position, 圆.radius, _轮廓填充)
			draw_arc(子.position, 圆.radius, 0.0, TAU, 48, _轮廓色, 1.5)
		elif 形状 is RectangleShape2D:
			var 矩 := 形状 as RectangleShape2D
			var 半 := 矩.size * 0.5
			var 区域 := Rect2(子.position - 半, 矩.size)
			draw_rect(区域, _轮廓填充, true)
			draw_rect(区域, _轮廓色, false, 1.5)

	var 文字: String
	var 颜色: Color
	if 启用:
		文字 = "⚔ 攻击中"
		颜色 = Color(1.0, 0.35, 0.35)
	else:
		文字 = "⚔ 待机"
		颜色 = Color(0.6, 0.6, 0.6)
	调试徽章.画(self, 徽章位置偏移, 文字, 颜色)
