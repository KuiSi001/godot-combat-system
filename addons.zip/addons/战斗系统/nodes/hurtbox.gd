class_name 受击盒 extends Area2D

signal 受到伤害(伤害: 伤害数据)
signal 被闪避(伤害: 伤害数据)
signal 格挡成功(伤害: 伤害数据)
signal 反伤触发(数值: float, 目标: 属性组件)

@export var 所属阵营: 阵营.类型 = 阵营.类型.B
@export var 调试无敌: bool = false
@export var 显示调试徽章: bool = true
@export var 徽章位置偏移: Vector2 = Vector2(0, -50)

var _属性组件: 属性组件
var _闪红剩余: float = 0.0
var _上次调试状态: bool = false
var _上次命中标记: String = ""
var _击退速度: Vector2 = Vector2.ZERO
var _原Sprite颜色: Dictionary = {} # 记录Sprite原始颜色，用于闪白恢复


func _ready() -> void:
	_属性组件 = _查找同级属性组件()
	if _属性组件 == null:
		push_error("[受击盒] 需要同级『属性组件』，节点已禁用：%s" % get_path())
		monitoring = false
		monitorable = false
		return
	monitoring = false
	monitorable = true
	_属性组件.无敌状态变化.connect(_当无敌变化)
	_属性组件.生命值变化.connect(_当生命值变化)
	_上次调试状态 = get_tree().debug_collisions_hint
	set_process(true)


func _查找同级属性组件() -> 属性组件:
	for 兄弟 in get_parent().get_children():
		if 兄弟 is 属性组件:
			return 兄弟
	return null


func 获取属性组件() -> 属性组件:
	return _属性组件


func 接收伤害(伤害: 伤害数据, 来源: Node = null) -> void:
	if _属性组件 == null:
		return
	if 调试无敌:
		return
	if _属性组件.是否无敌中():
		return

	# 未命中（被闪避）
	if not 伤害.是否命中:
		被闪避.emit(伤害)
		_显示标记("闪避", 0.12)
		_执行飘字("闪避", Color.CYAN, false)
		return

	# 无视护盾
	if 伤害.无视护盾:
		_属性组件.当前护盾值 = 0.0
		_属性组件.护盾值变化.emit(0.0, _属性组件.获取属性("最大护盾值"))

	# 扣血
	_属性组件.应用伤害(伤害.最终伤害)

	# 反伤
	var 反伤比例: float = _属性组件.获取属性("反伤比例")
	if 反伤比例 > 0.0 and 来源 is 攻击盒:
		var 攻击方属性 := (来源 as 攻击盒).获取属性组件()
		if 攻击方属性 != null and 攻击方属性 != _属性组件:
			var 反伤值: float = 伤害.最终伤害 * 反伤比例
			攻击方属性.应用伤害(反伤值)
			反伤触发.emit(反伤值, 攻击方属性)

	# 信号
	if 伤害.是否格挡:
		格挡成功.emit(伤害)
		_显示标记("格挡", 0.15)
	else:
		受到伤害.emit(伤害)
		_显示标记("命中", 0.12)

	# 触发反馈
	if _属性组件.受击反馈 != null:
		_执行反馈(伤害, 来源)

	# 无敌帧
	var 无敌时长: float = _属性组件.模板.受击无敌时间
	if 无敌时长 > 0.0:
		_属性组件.进入无敌(无敌时长)


# ─────────────────────────────────────────
#  受击反馈整合
# ─────────────────────────────────────────
func _执行反馈(伤害: 伤害数据, 来源: Node) -> void:
	var 设置 := _属性组件.受击反馈
	
	if 设置.启用闪白:
		_执行闪白(设置)
		
	if 设置.启用飘字:
		var 文字 := str(int(伤害.最终伤害))
		_执行飘字(文字, 设置.暴击字颜色 if 伤害.是否暴击 else 设置.普通字颜色, 伤害.是否暴击)
		
	if 设置.启用顿帧:
		_执行顿帧(设置)
		
	if 设置.启用击退 and 来源 is 攻击盒:
		var 攻击盒节点 := 来源 as 攻击盒
		if 攻击盒节点.招式.击退力度 > 0.0:
			_执行击退(攻击盒节点, 设置)


func _执行闪白(设置: 受击反馈设置) -> void:
	# 在父节点下找所有 Sprite2D 或 AnimatedSprite2D
	for 子 in get_parent().get_children():
		if 子 is CanvasItem and (子 is Sprite2D or 子 is AnimatedSprite2D or 子 is Polygon2D):
			var 画布 := 子 as CanvasItem
			if not _原Sprite颜色.has(画布):
				_原Sprite颜色[画布] = 画布.modulate
				
			画布.modulate = 设置.闪白颜色
			var tween := create_tween()
			tween.tween_property(画布, "modulate", _原Sprite颜色[画布], 设置.闪白时长)


func _执行顿帧(设置: 受击反馈设置) -> void:
	Engine.time_scale = 设置.顿帧时间缩放
	# ignore_time_scale = true 保证等待是真实时间
	await get_tree().create_timer(设置.顿帧时长, true, false, true).timeout
	Engine.time_scale = 1.0


func _执行击退(攻击盒节点: 攻击盒, 设置: 受击反馈设置) -> void:
	var 父 := get_parent()
	var 招式 := 攻击盒节点.招式
	
	# 1. 计算方向
	var 攻击方位置 := 攻击盒节点.global_position
	var 目标位置 := global_position
	var 方向 := (目标位置 - 攻击方位置).normalized()
	if 招式.击退方向 != Vector2.ZERO:
		方向 = 招式.击退方向.normalized()
		
	# 2. 计算最终力度
	var 抗性: float = _属性组件.获取属性("击退抗性")
	var 最终力度: float = 招式.击退力度 * 设置.击退系数 * (1.0 - 抗性)
	
	if 最终力度 <= 0.0:
		return # 力度为 0 直接跳过

	# 3. 施加击退
	# 优先调用父节点自定义的 "施加击退" 方法（如果存在的话）
	if 父.has_method("施加击退"):
		父.施加击退(方向, 最终力度)
	# 否则粗暴地直接加 velocity（需要配合下面的怪物脚本使用）
	elif 父 is CharacterBody2D:
		var 物理体 := 父 as CharacterBody2D
		物理体.velocity += 方向 * 最终力度


func _执行飘字(内容: String, 颜色: Color, 是大字: bool) -> void:
	var 设置 := _属性组件.受击反馈
	var 标签 := Label.new()
	标签.text = 内容
	标签.add_theme_color_override("font_color", 颜色)
	
	# 设置字号
	var 字号 := 设置.飘字大小
	if 是大字:
		字号 = int(字号 * 1.5)
	标签.add_theme_font_size_override("font_size", 字号)
	
	# 使用顶层 CanvasLayer 或者直接加在场景根节点，避免被 UI 遮挡
	get_tree().current_scene.add_child(标签)
	
	# 初始位置：受击盒的全局坐标中心
	标签.global_position = global_position + Vector2(-字号 * 0.5, -字号)
	
	# 动画：向上飘 + 逐渐透明 + 稍微放大
	var tween := 标签.create_tween()
	tween.set_parallel(true)
	tween.tween_property(标签, "global_position:y", 标签.global_position.y - 设置.飘字向上速度, 设置.飘字消散时长)\
		.set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)
	tween.tween_property(标签, "modulate:a", 0.0, 设置.飘字消散时长)\
		.set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_IN)
	
	if 是大字:
		tween.tween_property(标签, "scale", Vector2(1.2, 1.2), 设置.飘字消散时长 * 0.5)\
			.set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
			
	tween.chain().tween_callback(标签.queue_free)


# ─────────────────────────────────────────
#  原有调试逻辑
# ─────────────────────────────────────────
func _显示标记(标记: String, 时长: float) -> void:
	_上次命中标记 = 标记
	_闪红剩余 = 时长
	set_process(true)
	queue_redraw()


func _process(增量: float) -> void:
	var 需要重画 := false

	if _闪红剩余 > 0.0:
		_闪红剩余 -= 增量
		if _闪红剩余 <= 0.0:
			_闪红剩余 = 0.0
			_上次命中标记 = ""
		需要重画 = true

	var 当前 := get_tree().debug_collisions_hint
	if 当前 != _上次调试状态:
		_上次调试状态 = 当前
		需要重画 = true

	if 需要重画:
		queue_redraw()


func _当无敌变化(_是否无敌: bool) -> void:
	queue_redraw()
	set_process(true)

func _当生命值变化(_当前: float, _最大: float) -> void:
	queue_redraw()


# ─────────────────────────────────────────
#  可视化
# ─────────────────────────────────────────
const _常态轮廓 := Color(0.4, 0.7, 1.0, 0.55)
const _常态填充 := Color(0.4, 0.7, 1.0, 0.08)
const _无敌轮廓 := Color(0.3, 0.9, 1.0, 0.95)
const _无敌填充 := Color(0.3, 0.9, 1.0, 0.25)
const _闪红轮廓 := Color(1.0, 0.2, 0.2, 1.0)
const _闪红填充 := Color(1.0, 0.2, 0.2, 0.30)
const _闪蓝轮廓 := Color(0.6, 0.9, 1.0, 1.0)
const _闪蓝填充 := Color(0.6, 0.9, 1.0, 0.30)

func _draw() -> void:
	if not 显示调试徽章 or _属性组件 == null:
		return
	if not get_tree().debug_collisions_hint:
		return

	var 填充: Color
	var 描边: Color
	if _闪红剩余 > 0.0:
		match _上次命中标记:
			"闪避":
				填充 = _闪蓝填充
				描边 = _闪蓝轮廓
			_:
				填充 = _闪红填充
				描边 = _闪红轮廓
	elif _属性组件.是否无敌中():
		填充 = _无敌填充
		描边 = _无敌轮廓
	else:
		填充 = _常态填充
		描边 = _常态轮廓

	for 子 in get_children():
		if not 子 is CollisionShape2D:
			continue
		var 形状: Shape2D = (子 as CollisionShape2D).shape
		if 形状 == null:
			continue
		if 形状 is CircleShape2D:
			var 圆 := 形状 as CircleShape2D
			draw_circle(子.position, 圆.radius, 填充)
			draw_arc(子.position, 圆.radius, 0.0, TAU, 48, 描边, 1.5)
		elif 形状 is RectangleShape2D:
			var 矩 := 形状 as RectangleShape2D
			var 半 := 矩.size * 0.5
			var 区域 := Rect2(子.position - 半, 矩.size)
			draw_rect(区域, 填充, true)
			draw_rect(区域, 描边, false, 1.5)

	var 文字: String
	var 颜色: Color
	if _闪红剩余 > 0.0:
		match _上次命中标记:
			"闪避": 文字 = "💨 闪避"; 颜色 = Color(0.6, 0.9, 1.0)
			"格挡": 文字 = "🛡 格挡"; 颜色 = Color(1.0, 0.85, 0.3)
			_:      文字 = "💥 命中"; 颜色 = Color(1.0, 0.35, 0.35)
	elif _属性组件.是否无敌中():
		文字 = "🛡 无敌 %.1fs" % _属性组件.剩余无敌时间()
		颜色 = Color(0.3, 0.9, 1.0)
	elif 调试无敌:
		文字 = "🛡 强制无敌"
		颜色 = Color(0.3, 0.9, 1.0)
	else:
		文字 = "🛡 可受击"
		颜色 = Color(0.5, 0.85, 1.0)
	调试徽章.画(self, 徽章位置偏移, 文字, 颜色)
