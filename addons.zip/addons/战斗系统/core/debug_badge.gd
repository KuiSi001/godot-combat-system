class_name 调试徽章

const _字体大小 := 12
const _内边距 := Vector2(6, 4)
const _边框宽 := 1.5


## 在 CanvasItem 的本地坐标系上画一个状态徽章
## 目标：调用方（一般传 self）
## 位置：徽章左上角所在的本地坐标（一般传头顶上方）
## 文字：显示内容
## 颜色：文字 + 边框颜色
static func 画(目标: CanvasItem, 位置: Vector2, 文字: String, 颜色: Color) -> void:
	var 字体 := ThemeDB.fallback_font
	if 字体 == null:
		return

	var 文字尺寸 := 字体.get_string_size(文字, HORIZONTAL_ALIGNMENT_LEFT, -1, _字体大小)
	var 框尺寸 := 文字尺寸 + _内边距 * 2.0
	var 框位置 := 位置 - Vector2(框尺寸.x * 0.5, 框尺寸.y)
	var 矩形 := Rect2(框位置, 框尺寸)

	# 背景
	目标.draw_rect(矩形, Color(0.0, 0.0, 0.0, 0.7), true)
	# 边框
	目标.draw_rect(矩形, 颜色, false, _边框宽)
	# 文字（基线偏下一点才居中）
	var 文字位置 := 框位置 + Vector2(_内边距.x, _内边距.y + 文字尺寸.y * 0.78)
	目标.draw_string(字体, 文字位置, 文字,
		HORIZONTAL_ALIGNMENT_LEFT, -1, _字体大小, 颜色)
